var reaction_8hh =
[
    [ "xronos::sdk::ReactionContext", "classxronos_1_1sdk_1_1ReactionContext.html", null ],
    [ "xronos::sdk::BaseReaction", "classxronos_1_1sdk_1_1BaseReaction.html", "classxronos_1_1sdk_1_1BaseReaction" ],
    [ "xronos::sdk::BaseReaction::Trigger< T >", "classxronos_1_1sdk_1_1BaseReaction_1_1Trigger.html", "classxronos_1_1sdk_1_1BaseReaction_1_1Trigger" ],
    [ "xronos::sdk::Reaction< R >", "classxronos_1_1sdk_1_1Reaction.html", "classxronos_1_1sdk_1_1Reaction" ]
];