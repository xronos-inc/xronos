var classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4 =
[
    [ "PhysicalEvent", "classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4.html#a2042b44394735663333c7705f5692225", null ],
    [ "trigger", "classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4.html#aa4af8f803d2cb5a87704b58e4179adbb", null ]
];