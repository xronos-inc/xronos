var classxronos_1_1sdk_1_1BaseReaction =
[
    [ "Trigger", "classxronos_1_1sdk_1_1BaseReaction_1_1Trigger.html", "classxronos_1_1sdk_1_1BaseReaction_1_1Trigger" ],
    [ "BaseReaction", "classxronos_1_1sdk_1_1BaseReaction.html#a2eb9d3108e84b2e2e1e93fd32b813ead", null ],
    [ "context", "classxronos_1_1sdk_1_1BaseReaction.html#ac47cf758cd3f3a479a53a690528ce356", null ],
    [ "handler", "classxronos_1_1sdk_1_1BaseReaction.html#a7f0ddee3ad8d1bae9d94becc025e2a97", null ]
];