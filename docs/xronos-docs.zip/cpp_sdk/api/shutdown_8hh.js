var shutdown_8hh =
[
    [ "xronos::sdk::Shutdown", "classxronos_1_1sdk_1_1Shutdown.html", "classxronos_1_1sdk_1_1Shutdown" ]
];