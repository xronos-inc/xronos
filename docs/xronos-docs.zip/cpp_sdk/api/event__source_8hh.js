var event__source_8hh =
[
    [ "xronos::sdk::EventSource< T >", "classxronos_1_1sdk_1_1EventSource.html", null ],
    [ "xronos::sdk::EventSource< void >", "classxronos_1_1sdk_1_1EventSource_3_01void_01_4.html", null ]
];