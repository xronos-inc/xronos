var namespaces_dup =
[
    [ "xronos", null, [
      [ "sdk", "namespacexronos_1_1sdk.html", "namespacexronos_1_1sdk" ]
    ] ]
];