var group__effects =
[
    [ "xronos::sdk::BaseReaction::PortEffect< T >", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html", [
      [ "PortEffect", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#a87f6fea062c2125c4b2e8b649ddbb693", null ],
      [ "set", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#abc0a1a4cdf9324d44cd19158701263ce", null ],
      [ "set", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#a336561d556448f520177a0436c5fcb98", null ],
      [ "set", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#acb97382b7032b6c7813b5be3de5ba65d", null ],
      [ "set", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#aea3cfdacbabb9a135280cf26efe99bb9", null ],
      [ "set", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#a585468a65e3ff19d5b5e502f71368caf", null ],
      [ "get", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#a073590927c10acc3524fb7f1c7243e57", null ],
      [ "is_present", "classxronos_1_1sdk_1_1BaseReaction_1_1PortEffect.html#aa99b014e7580f2bf4f0ea18ddc72b6f6", null ]
    ] ],
    [ "xronos::sdk::BaseReaction::ProgrammableTimerEffect< T >", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html", [
      [ "ProgrammableTimerEffect", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html#ab3ad46868dabe47c6ea4c4be0caab917", null ],
      [ "schedule", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html#aefae2044f065f39a1cfee188213bb38b", null ],
      [ "schedule", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html#a4bb3d0da1acf5e6797028c05e9862959", null ],
      [ "schedule", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html#a60e9948d46b2e13aa7cc841d92dda807", null ],
      [ "schedule", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html#a215ed2a4c871110d3a8fe40dad4b9414", null ],
      [ "schedule", "classxronos_1_1sdk_1_1BaseReaction_1_1ProgrammableTimerEffect.html#a257b5b11303418dad4bfeaa42e582eee", null ]
    ] ],
    [ "xronos::sdk::BaseReaction::MetricEffect", "classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html", [
      [ "MetricEffect", "classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html#a995a3e7ad0d79370874e76133b6b0f33", null ],
      [ "record", "classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html#a6853410dfbe6784dbd64efd739c7f2b0", null ],
      [ "record", "classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html#af5c63dc5d581c369c048b48a4c477211", null ]
    ] ]
];