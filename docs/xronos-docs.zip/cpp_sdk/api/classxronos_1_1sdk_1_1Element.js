var classxronos_1_1sdk_1_1Element =
[
    [ "~Element", "classxronos_1_1sdk_1_1Element.html#ac2a007cae1bd4d8456e258730e2d24f6", null ],
    [ "name", "classxronos_1_1sdk_1_1Element.html#aa85c0cc3344ff5646dcac93cc0f25d41", null ],
    [ "fqn", "classxronos_1_1sdk_1_1Element.html#af93126c8a89905baf60a3c801da6fc55", null ],
    [ "add_attribute", "classxronos_1_1sdk_1_1Element.html#a732c42bbeeb04873b20e33ad5810ace1", null ],
    [ "add_attributes", "classxronos_1_1sdk_1_1Element.html#a503bcd838c184deeff62edb2e8f4c2be", null ],
    [ "add_attributes", "classxronos_1_1sdk_1_1Element.html#addccf4d34d6bb4396142ae57a8dc085d", null ]
];