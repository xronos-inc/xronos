var topics =
[
    [ "effects Reaction effect classes.", "group__effects.html", "group__effects" ]
];