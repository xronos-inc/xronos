var searchData=
[
  ['duration_0',['Duration',['../namespacexronos_1_1sdk.html#a8c9cae9122b3793094b7b18e6a519382',1,'xronos::sdk']]]
];
