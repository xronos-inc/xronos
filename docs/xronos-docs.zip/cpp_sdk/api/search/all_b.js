var searchData=
[
  ['name_0',['name',['../classxronos_1_1sdk_1_1Element.html#aa85c0cc3344ff5646dcac93cc0f25d41',1,'xronos::sdk::Element']]]
];
