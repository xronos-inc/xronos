var searchData=
[
  ['basereaction_0',['BaseReaction',['../classxronos_1_1sdk_1_1BaseReaction.html',1,'xronos::sdk::BaseReaction'],['../classxronos_1_1sdk_1_1BaseReaction.html#a2eb9d3108e84b2e2e1e93fd32b813ead',1,'xronos::sdk::BaseReaction::BaseReaction()']]]
];
