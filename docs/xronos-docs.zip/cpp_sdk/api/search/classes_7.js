var searchData=
[
  ['shutdown_0',['Shutdown',['../classxronos_1_1sdk_1_1Shutdown.html',1,'xronos::sdk']]],
  ['startup_1',['Startup',['../classxronos_1_1sdk_1_1Startup.html',1,'xronos::sdk']]]
];
