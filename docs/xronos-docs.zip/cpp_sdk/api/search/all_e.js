var searchData=
[
  ['reaction_0',['Reaction',['../classxronos_1_1sdk_1_1Reaction.html',1,'xronos::sdk::Reaction&lt; R &gt;'],['../classxronos_1_1sdk_1_1Reaction.html#a40600488cb4e482ba25d2718561b1a85',1,'xronos::sdk::Reaction::Reaction()']]],
  ['reaction_20effect_20classes_1',['effects Reaction effect classes.',['../group__effects.html',1,'']]],
  ['reaction_2ehh_2',['reaction.hh',['../reaction_8hh.html',1,'']]],
  ['reactioncontext_3',['ReactionContext',['../classxronos_1_1sdk_1_1ReactionContext.html',1,'xronos::sdk']]],
  ['reactionproperties_4',['ReactionProperties',['../classxronos_1_1sdk_1_1ReactionProperties.html',1,'xronos::sdk']]],
  ['reactor_5',['Reactor',['../classxronos_1_1sdk_1_1Reactor.html',1,'xronos::sdk::Reactor'],['../classxronos_1_1sdk_1_1Reactor.html#a08fdea7dec55e5c5fff9802dea6380e7',1,'xronos::sdk::Reactor::Reactor()']]],
  ['reactor_2ehh_6',['reactor.hh',['../reactor_8hh.html',1,'']]],
  ['reactorcontext_7',['ReactorContext',['../classxronos_1_1sdk_1_1ReactorContext.html',1,'xronos::sdk']]],
  ['record_8',['record',['../classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html#a6853410dfbe6784dbd64efd739c7f2b0',1,'xronos::sdk::BaseReaction::MetricEffect::record(double value) noexcept'],['../classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html#af5c63dc5d581c369c048b48a4c477211',1,'xronos::sdk::BaseReaction::MetricEffect::record(std::int64_t value) noexcept']]],
  ['request_5fshutdown_9',['request_shutdown',['../classxronos_1_1sdk_1_1Environment.html#abf5bd5148ead59aff66f2b626ba5a4fc',1,'xronos::sdk::Environment::request_shutdown()'],['../classxronos_1_1sdk_1_1Reactor.html#afb9c6728c3c89c63adf6821b39e3aae1',1,'xronos::sdk::Reactor::request_shutdown()']]]
];
