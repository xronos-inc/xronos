var searchData=
[
  ['xronos_3a_3asdk_0',['sdk',['../namespacexronos_1_1sdk.html',1,'xronos']]],
  ['xronos_3a_3asdk_3a_3aoperators_1',['operators',['../namespacexronos_1_1sdk_1_1operators.html',1,'xronos::sdk']]]
];
