var searchData=
[
  ['make_5fimmutable_5fvalue_0',['make_immutable_value',['../namespacexronos_1_1sdk.html#ac8b739e85622837c70670e9f564d1aa4',1,'xronos::sdk']]],
  ['make_5fmutable_5fvalue_1',['make_mutable_value',['../namespacexronos_1_1sdk.html#a8419c977b183e97698d702898a1f5ffb',1,'xronos::sdk']]],
  ['metric_2',['Metric',['../classxronos_1_1sdk_1_1Metric.html',1,'xronos::sdk::Metric'],['../classxronos_1_1sdk_1_1Metric.html#adb351bed909d0dc6cfd06b0622706a9c',1,'xronos::sdk::Metric::Metric()']]],
  ['metric_2ehh_3',['metric.hh',['../metric_8hh.html',1,'']]],
  ['metriceffect_4',['MetricEffect',['../classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html',1,'xronos::sdk::BaseReaction::MetricEffect'],['../classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html#a995a3e7ad0d79370874e76133b6b0f33',1,'xronos::sdk::BaseReaction::MetricEffect::MetricEffect()']]],
  ['mutablevalueptr_5',['MutableValuePtr',['../namespacexronos_1_1sdk.html#af1dad43def2dc316b364395475949e3a',1,'xronos::sdk']]]
];
