var searchData=
[
  ['immutablevalueptr_0',['ImmutableValuePtr',['../namespacexronos_1_1sdk.html#aef77eee7e6b42f277af60482f5c7769e',1,'xronos::sdk']]]
];
