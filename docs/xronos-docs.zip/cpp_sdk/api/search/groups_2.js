var searchData=
[
  ['reaction_20effect_20classes_0',['effects Reaction effect classes.',['../group__effects.html',1,'']]]
];
