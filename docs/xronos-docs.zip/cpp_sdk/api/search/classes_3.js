var searchData=
[
  ['metric_0',['Metric',['../classxronos_1_1sdk_1_1Metric.html',1,'xronos::sdk']]],
  ['metriceffect_1',['MetricEffect',['../classxronos_1_1sdk_1_1BaseReaction_1_1MetricEffect.html',1,'xronos::sdk::BaseReaction']]]
];
