var searchData=
[
  ['description_0',['description',['../classxronos_1_1sdk_1_1Metric.html#a1322783ce2dbef865af5faed628d55ea',1,'xronos::sdk::Metric']]]
];
