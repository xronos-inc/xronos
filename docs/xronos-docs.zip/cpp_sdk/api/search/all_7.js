var searchData=
[
  ['handler_0',['handler',['../classxronos_1_1sdk_1_1BaseReaction.html#a7f0ddee3ad8d1bae9d94becc025e2a97',1,'xronos::sdk::BaseReaction']]]
];
