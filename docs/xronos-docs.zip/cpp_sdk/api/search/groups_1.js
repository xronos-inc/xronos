var searchData=
[
  ['effect_20classes_0',['effects Reaction effect classes.',['../group__effects.html',1,'']]],
  ['effects_20reaction_20effect_20classes_1',['effects Reaction effect classes.',['../group__effects.html',1,'']]]
];
