var searchData=
[
  ['classes_0',['effects Reaction effect classes.',['../group__effects.html',1,'']]]
];
