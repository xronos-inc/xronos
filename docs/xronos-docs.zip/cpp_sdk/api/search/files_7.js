var searchData=
[
  ['value_5fptr_2ehh_0',['value_ptr.hh',['../value__ptr_8hh.html',1,'']]]
];
