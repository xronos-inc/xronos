var searchData=
[
  ['xronos_20c_20sdk_0',['Xronos C++ SDK',['../index.html',1,'']]],
  ['xronos_3a_3asdk_1',['sdk',['../namespacexronos_1_1sdk.html',1,'xronos']]],
  ['xronos_3a_3asdk_3a_3aoperators_2',['operators',['../namespacexronos_1_1sdk_1_1operators.html',1,'xronos::sdk']]]
];
