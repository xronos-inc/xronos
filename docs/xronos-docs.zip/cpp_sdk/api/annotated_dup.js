var annotated_dup =
[
    [ "xronos", null, [
      [ "sdk", "namespacexronos_1_1sdk.html", [
        [ "BaseReaction", "classxronos_1_1sdk_1_1BaseReaction.html", "classxronos_1_1sdk_1_1BaseReaction" ],
        [ "Element", "classxronos_1_1sdk_1_1Element.html", "classxronos_1_1sdk_1_1Element" ],
        [ "Environment", "classxronos_1_1sdk_1_1Environment.html", "classxronos_1_1sdk_1_1Environment" ],
        [ "EnvironmentContext", "classxronos_1_1sdk_1_1EnvironmentContext.html", null ],
        [ "EventSource", "classxronos_1_1sdk_1_1EventSource.html", null ],
        [ "EventSource< void >", "classxronos_1_1sdk_1_1EventSource_3_01void_01_4.html", null ],
        [ "InputPort", "classxronos_1_1sdk_1_1InputPort.html", "classxronos_1_1sdk_1_1InputPort" ],
        [ "Metric", "classxronos_1_1sdk_1_1Metric.html", "classxronos_1_1sdk_1_1Metric" ],
        [ "OutputPort", "classxronos_1_1sdk_1_1OutputPort.html", "classxronos_1_1sdk_1_1OutputPort" ],
        [ "PeriodicTimer", "classxronos_1_1sdk_1_1PeriodicTimer.html", "classxronos_1_1sdk_1_1PeriodicTimer" ],
        [ "PhysicalEvent", "classxronos_1_1sdk_1_1PhysicalEvent.html", "classxronos_1_1sdk_1_1PhysicalEvent" ],
        [ "PhysicalEvent< void >", "classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4.html", "classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4" ],
        [ "Port", "classxronos_1_1sdk_1_1Port.html", null ],
        [ "Port< void >", "classxronos_1_1sdk_1_1Port_3_01void_01_4.html", null ],
        [ "ProgrammableTimer", "classxronos_1_1sdk_1_1ProgrammableTimer.html", "classxronos_1_1sdk_1_1ProgrammableTimer" ],
        [ "ProgrammableTimer< void >", "classxronos_1_1sdk_1_1ProgrammableTimer_3_01void_01_4.html", "classxronos_1_1sdk_1_1ProgrammableTimer_3_01void_01_4" ],
        [ "Reaction", "classxronos_1_1sdk_1_1Reaction.html", "classxronos_1_1sdk_1_1Reaction" ],
        [ "ReactionContext", "classxronos_1_1sdk_1_1ReactionContext.html", null ],
        [ "ReactionProperties", "classxronos_1_1sdk_1_1ReactionProperties.html", null ],
        [ "Reactor", "classxronos_1_1sdk_1_1Reactor.html", "classxronos_1_1sdk_1_1Reactor" ],
        [ "ReactorContext", "classxronos_1_1sdk_1_1ReactorContext.html", null ],
        [ "Shutdown", "classxronos_1_1sdk_1_1Shutdown.html", "classxronos_1_1sdk_1_1Shutdown" ],
        [ "Startup", "classxronos_1_1sdk_1_1Startup.html", "classxronos_1_1sdk_1_1Startup" ],
        [ "TestEnvironment", "classxronos_1_1sdk_1_1TestEnvironment.html", "classxronos_1_1sdk_1_1TestEnvironment" ],
        [ "ValidationError", "classxronos_1_1sdk_1_1ValidationError.html", null ]
      ] ]
    ] ]
];