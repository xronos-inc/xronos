var value__ptr_8hh =
[
    [ "xronos::sdk::MutableValuePtr", "namespacexronos_1_1sdk.html#af1dad43def2dc316b364395475949e3a", null ],
    [ "xronos::sdk::ImmutableValuePtr", "namespacexronos_1_1sdk.html#aef77eee7e6b42f277af60482f5c7769e", null ],
    [ "xronos::sdk::make_immutable_value", "namespacexronos_1_1sdk.html#ac8b739e85622837c70670e9f564d1aa4", null ],
    [ "xronos::sdk::make_mutable_value", "namespacexronos_1_1sdk.html#a8419c977b183e97698d702898a1f5ffb", null ]
];