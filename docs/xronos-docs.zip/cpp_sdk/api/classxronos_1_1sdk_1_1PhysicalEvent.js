var classxronos_1_1sdk_1_1PhysicalEvent =
[
    [ "PhysicalEvent", "classxronos_1_1sdk_1_1PhysicalEvent.html#a4d557f38770b29c0ab07661d91200a0f", null ],
    [ "trigger", "classxronos_1_1sdk_1_1PhysicalEvent.html#a1c61dc212cbad96427dff46d62ca21dd", null ],
    [ "trigger", "classxronos_1_1sdk_1_1PhysicalEvent.html#adcde0cb9da274c3d8a17d3c45555420c", null ],
    [ "trigger", "classxronos_1_1sdk_1_1PhysicalEvent.html#aaaf66586b84104b034d95e5f9a58f678", null ],
    [ "trigger", "classxronos_1_1sdk_1_1PhysicalEvent.html#aa8bab6becd33bc0df5f6f77caa57facb", null ]
];