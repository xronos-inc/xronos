var classxronos_1_1sdk_1_1Metric =
[
    [ "Metric", "classxronos_1_1sdk_1_1Metric.html#adb351bed909d0dc6cfd06b0622706a9c", null ],
    [ "description", "classxronos_1_1sdk_1_1Metric.html#a1322783ce2dbef865af5faed628d55ea", null ],
    [ "unit", "classxronos_1_1sdk_1_1Metric.html#afa42343f5a2d08d664a89ffef8d1ba59", null ]
];