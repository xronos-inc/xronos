var physical__event_8hh =
[
    [ "xronos::sdk::PhysicalEvent< T >", "classxronos_1_1sdk_1_1PhysicalEvent.html", "classxronos_1_1sdk_1_1PhysicalEvent" ],
    [ "xronos::sdk::PhysicalEvent< void >", "classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4.html", "classxronos_1_1sdk_1_1PhysicalEvent_3_01void_01_4" ]
];